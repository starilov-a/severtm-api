<?php

namespace App\Modules\UserCabinet\Application\UseCase\TariffGroup;

use App\Modules\UserCabinet\Domain\Entity\Tariff;
use App\Modules\UserCabinet\Domain\Entity\TariffGroup;
use App\Modules\UserCabinet\Domain\Repository\UserRepository;
use App\Modules\UserCabinet\Domain\Repository\WebActionRepository;
use App\Modules\UserCabinet\Domain\Service\TariffGroupService;
use App\Modules\UserCabinet\Domain\Service\TariffService;
use App\Modules\UserCabinet\Infrastructure\Service\Logger\LoggerService;

class CommandLinkTariffForGroupUseCase
{
    public function __construct(
        protected WebActionRepository $webActionRepo,
        protected UserRepository $userRepo,

        protected LoggerService $loggerService,
        protected TariffService $tariffService,
        protected TariffGroupService $tariffGroupService,
    ) {}
    public function handle(Tariff $tariff, TariffGroup $tariffGroup): bool
    {
        // 1. Добавляем бизнес-проверки проверки

        // 2. Добавляем
        $tariff = $this->tariffGroupService->linkTariffForGroup($tariff, $tariffGroup);
        $this->tariffService->save($tariff);

        // 4. запись в историю об успехе

        return true;
    }
}
