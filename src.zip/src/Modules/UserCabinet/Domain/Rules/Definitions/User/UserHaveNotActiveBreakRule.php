<?php

namespace App\Modules\UserCabinet\Domain\Rules\Definitions\User;

use App\Modules\Common\Rules\Results\RuleResult;
use App\Modules\Common\Rules\Rule;
use App\Modules\UserCabinet\Domain\Contexts\Interfaces\HasUser;

class UserHaveNotActiveBreakRule extends Rule
{
    public function __construct(
    ){}
    public function check(object $context = null): RuleResult
    {
        if (!($context instanceof HasUser))
            throw new \LogicException('Wrong context passed to UserHaveNotActiveBreakRule');

        if ($context->getUser()->isCredit())
            return RuleResult::fail("Пользователь имеет активную отсрочку");

        return RuleResult::ok();
    }
}